FROM ollama/ollama:0.34.0
USER root
RUN mkdir -p /home/ollama/models && chown -R 1000:1000 /home/ollama
ENV HOME=/home/ollama
ENV OLLAMA_MODELS=/home/ollama/models
USER 1000:1000
