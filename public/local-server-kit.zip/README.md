# Athena local installation — owner-operated preview

This kit packages the web client, TLS gateway, existing proxy/core, MySQL memory
storage, Ollama and Kiwix. It is not yet an unattended first-install product.
Run it from `deploy/local` in a trusted Athena source checkout. The downloaded
kit must be extracted there, not run independently of the application source.

## Before starting

1. Install Docker with Compose on the owner's chosen host. CPU inference is the
   portable default; enable a GPU only after verifying host support against
   https://docs.ollama.com/docker. Choose model sizes for that host. Large
   Wikipedia editions can consume substantial disk space: choose the language,
   edition, download size and model licenses before downloading anything.
2. Copy `.env.example` to `.env`, and each `*.env.example` to `*.env`. Replace all
   placeholders with fresh local values. Never reuse the repository's live `.env`
   files. Core and proxy need the same new JWT secret. Database owner credentials
   belong only in `database.env`; the core uses a restricted account.
3. Configure a hostname under an owner-controlled domain resolving to the host's
   LAN IP, and supply a browser-trusted certificate and key in `certs/fullchain.pem`
   and `certs/privkey.pem`. The non-root gateway must be able to read them.
   Register `https://<ATHENA_HOST>` as an authorized Google OAuth JavaScript origin.
   Do not disable browser certificate checks. Google sign-in still needs internet.
4. Leave `ATHENA_BIND_IP=127.0.0.1` during preparation. When ready, set the specific
   LAN interface address and restrict incoming ports 443 and 8082 to trusted LAN
   clients with the host firewall. Do not forward router ports to the internet.
   Core, database, proxy and Ollama have no published ports.

## Database and memories: required preparation

The checked-in migrations ALTER legacy tables including `profile`, `session` and
`message`; their baseline CREATE scripts are absent. Running migrations against
an empty MySQL database is insufficient. Obtain an owner-reviewed compatible
schema and a consent-scoped export before bringing up core. Do not copy the full
multi-user production database to a household server.

Start just the database: `docker compose up -d database`. Restore the reviewed
schema/data using an owner database session (for example, copy the reviewed SQL
into the database container, then use `docker compose exec database mysql -uroot -p`
and MySQL's SOURCE command). Preserve IDs and relational dependencies for profiles,
sessions, messages, facts, events, consent and embeddings. Include the matching
`schema_migrations` ledger. Apply pending migrations with a temporary owner
environment using `core_api/db/migrate.js`; never give core DDL privileges.

Create `athena_runtime` with the table/column privileges in
`docs/architecture/guardian-access.md`. It cannot write access grants or Guardian
identity/activation fields. Establish local Guardian records or an explicit grant
with the existing owner-only `core_api/db/access-admin.js` utility. Keep its admin
credentials off core. New profile roles cannot grant access. Verify denied users
cannot call models before allowing use. No runtime service receives Docker access.

Memory vectors use `home:nomic-embed-text`; imported vectors from a different
embedding space are not interchangeable. Use the existing backfill with an
explicitly authorized background identity, or allow keyword recall until vectors
are rebuilt. Photo bytes currently stored in browser storage and remote media
references need separate export; copying SQL alone does not relocate them.
Encrypted integration tokens need a deliberate key migration or relinking.

This preview has no cloud/local synchronization. Choose the authoritative store
and a cutover time. Cloud fallback can create separate history. Before switching,
take an encrypted backup, verify restoration, and retain the original for rollback.
Named volumes survive `docker compose down`; `down -v` deletes memories/models.

## Models and Wikipedia

Start Ollama: `docker compose up -d ollama`. These explicit commands download the
models used by this kit (change both the model configuration and pulls together):

```
docker compose exec ollama ollama pull qwen2.5:7b-instruct
docker compose exec ollama ollama pull qwen2.5vl:7b
docker compose exec ollama ollama pull nomic-embed-text
```

Choose a Wikipedia ZIM at https://library.kiwix.org/, verify its published checksum
when supplied, and put it under `wikipedia/`. Kiwix serves that local snapshot at
`http://<LAN-IP>:8082`; it is public to clients allowed by your firewall. It does
not contain private Athena memories. See the official server instructions:
https://github.com/kiwix/kiwix-tools/blob/main/docker/server/README.md.
Pin the Kiwix image to a reviewed digest before a production installation.
Automatic Wikipedia retrieval into Athena's answers is a separate planned feature;
this kit provides the browsable offline library only.

## Start and connect

After all preparation, run `docker compose config --quiet`, then
`docker compose up -d --build`. This builds code and starts persistent services.
Open `https://<ATHENA_HOST>` and sign in. Confirm access, Brain status, chat,
WebSocket reconnect, memory write/recall, and the Wikipedia library. Restart the
stack and confirm a test memory persists. Test denial with an unapproved account.

In the web companion menu choose **Local server**, enter that HTTPS origin,
approve it, check the connection, and save. The cloud page probes only that saved
origin without credentials, then opens the local client before sign-in. Local and
cloud cookies are never transferred. Browser LAN permission may be required:
https://developer.chrome.com/blog/local-network-access.
When discovery is blocked, opening the local origin directly avoids cross-site
discovery. Discovery is identification, not authentication or dependency readiness.
The actual API enforces existing identity and live authorization checks.

Cloud fallback is off by default. If explicitly enabled, it happens only when
discovery fails at page startup; a live local request is never retried against
cloud. Reopen the original cloud URL to check local availability again. Mid-session
network transitions and automatic memory reconciliation are not implemented.

For frontier fallback on the local server, set its own `GEMINI_API_KEY` after
owner approval. The existing guarded model router tries local models first for
supported tasks. TTS/tools remain frontier-only; child policy remains unchanged.
This is not fully offline: Google login and default Unity asset loading still
require internet. Plan local assets and an owner-approved offline identity design
before promising offline operation.

## Release gates still required

- Recover and test the legacy baseline schema; build a scoped memory exporter/importer.
- Validate this stack on the selected host, TLS/OAuth origin and actual DB grants.
- Add a signed installer with resumable, checksum-verified downloads and rollback.
- Add Wikipedia retrieval with article/version citations, then test grounded answers.
- Define consent-aware memory synchronization and conflict handling before auto-roaming.
- Verify mobile browsers, denied LAN permission, lost Wi-Fi and real access revocation.

No host changes, certificate provisioning, production data export, downloads,
grant changes or firewall changes are performed merely by opening the web guide.
