$ErrorActionPreference = 'Stop'
# Explicit allowlist: never include certificates, runtime secrets or memory exports.
$kitFiles = @('compose.yaml', 'Caddyfile', 'Ollama.Dockerfile', 'README.md', '.env.example', 'core.env.example', 'proxy.env.example', 'database.env.example', '.gitignore', '.dockerignore', 'build-kit.ps1')
$kitPaths = $kitFiles | ForEach-Object { Join-Path $PSScriptRoot $_ }
$kitDestination = Join-Path $PSScriptRoot '../../companion/public/local-server-kit.zip'
Compress-Archive -LiteralPath $kitPaths -DestinationPath $kitDestination -Force
